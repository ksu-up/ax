baseDir="$(dirname "$(readlink -f "$0")")"
[ -f "$baseDir/nga-utils.sh" ] && . "$baseDir/nga-utils.sh" || exit

until_boot 1

run_bin "$baseDir/Rokyokyo-Karakuchi"